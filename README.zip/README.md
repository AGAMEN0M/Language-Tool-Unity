# Language-Tool-Unity
A tool that helps you translate your games and facilitates translation by fans.

# Download

[Language - Package v0.2.2]()
 / 
[Documentation]()

[Emoji System Base - Package v0.0.9]()
 / 
[Documentation]()

# Description

This tool is compatible with TextMeshPro. 

You can find more information on how to use it on the YouTube Playlist: [Click Here.](https://www.youtube.com/playlist?list=PL5hnfx09yM4JkAyxrZWaFjhO3NMWxP_1F)

If you have suggestions for improvements and bug fixes, please share them with me so we can improve this package as much as possible.

# Old Versions
[Old Versions - Package](https://drive.google.com/drive/folders/1btxBK7_OI_U6zOee_tYZ26kVlsOkkKCR?usp=drive_link)

Current version in Git v0.6